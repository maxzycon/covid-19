<!-- Assets -->
https://stories.freepik.com/illustration/preventive-measures-when-you-get-home-covid/cuate
https://stories.freepik.com/illustration/fighting-against-coronavirus/cuate
https://stories.freepik.com/illustration/kids-studying-from-home/cuate
https://stories.freepik.com/illustration/time-management/bro
https://stories.freepik.com/illustration/otters-swimming/bro
https://stories.freepik.com/illustration/pray/cuate
https://www.manypixels.co/gallery/

<!-- Font -->
https://fonts.google.com/specimen/Proza+Libre?query=proza
https://fonts.google.com/specimen/Open+Sans?query=open

<!-- Icons -->
https://www.flaticon.com/
https://heroicons.dev/

<!-- video -->
https://youtu.be/ftNCj06d7KE

<!-- colors -->
https://coolors.co/

<!-- Library -->
https://www.highcharts.com/
https://inorganik.github.io/countUp.js/
https://gitbrent.github.io/bootstrap4-toggle/

<!-- Peserta -->
Nama : Oskar Maha Kasi
Sekolah : SMA NEGERI 1 BEBANDEM
Kontak : 081370573844
Email : oskaresvada@yahoo.com

<!-- link website -->
https://lombawdc.developed.link/

copyright oskar maha kasi @2020 
        Made with ❤️